/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.drivers;

import robot.world.Robot;
import robot.*;

/**
 *
 * @author stswoon
 */
public class AngleDriver extends SimpleDriver {

	public AngleDriver(Robot robot, double delta) {
		super(robot, delta);
	}

	/**
	 * увеличиваем а
	 */
	@Override
	public void inc() {
		getRobot().setA(getRobot().getA() + getDelta());
	}

	/**
	 * уменьшаем а
	 */
	@Override
	public void dec() {
		getRobot().setA(getRobot().getA() - getDelta());
	}

}
