/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.ais;

import java.util.Vector;

/**
 *
 * @author stswoon
 */
public interface Net {

	void setInput(Vector<Double> input);

	Vector<Double> getOutput();

	void calculate();

	Integer getWinner();

	void education(boolean right);

	void setAlpha(double a);

	double getAlpha();

	void save(String s);

	void load(String s);

}
