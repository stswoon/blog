/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.world;

/**
 *
 * @author stswoon
 */
public class Robot extends Circle implements WorldObject{


	private double a = 0; //угол против часовой стрелки

	public Robot(double x, double y, double r) {
		super(x, y, r);
	}

	public double getA() {
		return a;
	}

	/**
	 * перед установкой переводит а в [0; 2*PI]
	 * @param a
	 */
	public void setA(double a) {
		if (a < 0){
			//a += (2 * Math.PI) * Math.floor(Math.abs(a) / (2 * Math.PI));
			a += (2 * Math.PI) * Math.ceil(Math.abs(a) / (2 * Math.PI));
		}
		if(a > 2 * Math.PI) {
			a -= (2 * Math.PI) * Math.floor(Math.abs(a) / (2 * Math.PI));
		}
		this.a = a;
	}
	

}
