/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot;

/**
 *
 * @author stswoon
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
		View view = new View();
		view.setVisible(true);
    }

}
