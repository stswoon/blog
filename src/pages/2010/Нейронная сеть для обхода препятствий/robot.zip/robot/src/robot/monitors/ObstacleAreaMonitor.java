/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.monitors;

import java.util.Vector;
import robot.world.Robot;
import robot.world.World;

/**
 *
 * @author stswoon
 */
public class ObstacleAreaMonitor extends SimpleMonitor{

	private	ObstacleDistanceMonitor dm = null;
	private	ObstacleAngleMonitor am = null;
	private final int n = 6; //количество областей

	public ObstacleAreaMonitor(Robot robot, World world, ObstacleDistanceMonitor dm, ObstacleAngleMonitor am) {
		super(robot, world);
		this.am = am;
		this.dm = dm;
	}

	public Vector<Double> get() {
		Vector<Double> v = new Vector<Double>();
		for(int i = 0; i < n; i++){
			v.add(new Double(0));
		}
		double d = dm.get();
		double a = am.get();
		int x = -100;
		int y = -100;

		if ((d >= 0) && (d < 10)){
			x = 0;
		} else if ((d >= 10) && (d < 20)){
			x = 1;
		}

		if (((a >= 0) && (a < Math.PI/4)) ||
			((a >= 7*Math.PI/4) && (a <= 8*Math.PI/4))){
			y = 0;
			//y = 2;
		} else if ((a >= Math.PI/4) && (a < Math.PI/2)){
			y = 1;
			//y = 3;
		} else if ((a >= 3*Math.PI/2) && (a < 7*Math.PI/4)){
			y = 2;
			//y = 0;
		//} else if ((a >= 5*Math.PI/4) && (a < 7*Math.PI/4)){
		//	y = 3;
			//y = 1;
		}

		if(x >= 0 && y >=0)	{
			v.set(3*x+y, new Double(1));
			//System.out.println(" i see");
		}

		//System.out.print(y);
		//System.out.print(" ");
		//System.out.print(x);
		//System.out.print(" ");
		//System.out.print(d);
		//System.out.print(" ");
		//System.out.print(a);
		//System.out.println();
		
		return v;
	}

}