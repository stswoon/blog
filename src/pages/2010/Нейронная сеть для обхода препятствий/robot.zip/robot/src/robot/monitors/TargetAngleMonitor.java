/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.monitors;

import robot.world.World;
import robot.world.Robot;
import robot.world.Target;

/**
 *
 * @author stswoon
 */
public class TargetAngleMonitor extends SimpleMonitor{

	public TargetAngleMonitor(Robot robot, World world) {
		super(robot, world);
	}

    static public double module(double x, double y){
        return Math.sqrt(x*x + y*y);
    }

    static public double getAngle(double x1, double y1, double x2, double y2){
		if ((module(x1, y1) == 0) || (module(x2,y2) == 0)) {
			return 0;
		}

		double a1 = (x1*y2 - y1*x2)/(module(x1,y1) * module(x2,y2));
		double a2 = (x1*x2 + y1*y2)/(module(x1,y1) * module(x2,y2));
		double aa1 = Math.asin(a1);
		double aa2 = Math.acos(a2);
		double a = 0;

		if((a1>=0)&&(a2>=0)){
			a = aa1;
		}
		if((a1>=0)&&(a2<=0)){
			a = /*Math.PI -*/ aa2;
		}
		if((a1<=0)&&(a2<=0)){
			a = 2*Math.PI - aa2;
		}
		if((a1<=0)&&(a2>=0)){
			a = 2*Math.PI - aa2;
		}

		//if (a < 0) {
		 //   a += 2*Math.PI;
		//}
		//Double d = new Double(a);
		//if (d.isNaN()) a = 0;
		return a;
    }

	public Double get() {
		Robot r = getRobot();
		Target t = getWorld().getFirstTarget();

		double a = r.getA();

		return getAngle(t.getX()-r.getX(), t.getY()-r.getY(), Math.cos(a),  Math.sin(a));
	}

}
