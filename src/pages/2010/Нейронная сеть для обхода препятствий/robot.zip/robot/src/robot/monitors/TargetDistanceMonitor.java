/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.monitors;

import robot.world.World;
import robot.world.Robot;
import robot.world.WorldObject;
import robot.world.Target;

/**
 *
 * @author stswoon
 */
public class TargetDistanceMonitor extends SimpleMonitor{

	public TargetDistanceMonitor(Robot robot, World world) {
		super(robot, world);
	}
	
	/**
	 * distance between nearest target and robot
	 * @return
	 */
	public Double get() {
		double dist = -1;
		for (WorldObject wo : getWorld().getWorldObjects()) {
			if (wo instanceof Target){
				Target t = (Target) wo;
				double dx = t.getX() - getRobot().getX();
				double dy = t.getY() - getRobot().getY();
				dist = Math.hypot(dx, dy);
			}
		}
		return dist;
	}


}
