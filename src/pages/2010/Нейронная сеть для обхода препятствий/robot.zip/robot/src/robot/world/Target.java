/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.world;

/**
 *
 * @author stswoon
 */
public class Target extends Circle implements WorldObject{

	public Target(double x, double y, double r) {
		super(x, y, r);
	}

}
