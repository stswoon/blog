/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.drivers;

import robot.world.Robot;
import robot.*;

/**
 *
 * @author stswoon
 */
public class MovingDriver extends SimpleDriver {

	public MovingDriver(Robot robot, double delta) {
		super(robot, delta);
	}

	/**
	 * движение вперед
	 */
	@Override
	public void inc() {
		getRobot().setX(
				getRobot().getX() +
				getDelta() * Math.cos(getRobot().getA())
				);
		getRobot().setY(
				getRobot().getY() +
				getDelta() * Math.sin(getRobot().getA())
				);
	}

	/**
	 * движение назад
	 */
	@Override
	public void dec() {
		getRobot().setX(
				getRobot().getX() -
				getDelta() * Math.cos(getRobot().getA())
				);
		getRobot().setY(
				getRobot().getY() -
				getDelta() * Math.sin(getRobot().getA())
				);
	}

}
