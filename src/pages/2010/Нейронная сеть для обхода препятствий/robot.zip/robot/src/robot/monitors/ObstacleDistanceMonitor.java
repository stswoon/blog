/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.monitors;

import robot.world.Boundary;
import robot.world.Obstacle;
import robot.world.Robot;
import robot.world.World;
import robot.world.WorldObject;

/**
 *
 * @author stswoon
 */
public class ObstacleDistanceMonitor extends SimpleMonitor{

	public ObstacleDistanceMonitor(Robot robot, World world) {
		super(robot, world);
	}

		/**
	 * distance between nearest target and robot
	 * @return
	 */
	public Double get() {
		double dist = 1000000;
		for (WorldObject wo : getWorld().getWorldObjects()) {
			if (wo instanceof Obstacle){
				Obstacle obst = (Obstacle) wo;
				double dx = obst.getX() - getRobot().getX();
				double dy = obst.getY() - getRobot().getY();
				double d = Math.hypot(dx, dy);
				d -= (getRobot().getR() + obst.getR())/2.0;
				dist = Math.min(dist, d);
			}
			if (wo instanceof Boundary) {
				Boundary b = (Boundary) wo;
				Robot r = getRobot();
				double d = Math.abs(r.getX()-b.getX());
				d = Math.min(d, Math.abs(r.getY()-b.getY()));
				d = Math.min(d, Math.abs(r.getX()-(b.getW()+b.getX())));
				d = Math.min(d, Math.abs(r.getY()-(b.getH()+b.getY())));
				d = Math.abs(d - r.getR()/2.0);
				dist = Math.min(dist, d);
			}
		}
		return dist;
	}
}
