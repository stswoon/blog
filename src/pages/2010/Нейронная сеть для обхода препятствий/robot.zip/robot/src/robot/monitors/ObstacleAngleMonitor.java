/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.monitors;

import robot.world.Boundary;
import robot.world.Circle;
import robot.world.Obstacle;
import robot.world.Robot;
import robot.world.World;
import robot.world.WorldObject;

/**
 *
 * @author stswoon
 */
public class ObstacleAngleMonitor extends SimpleMonitor{

	public ObstacleAngleMonitor(Robot robot, World world) {
		super(robot, world);
	}

    static public double module(double x, double y){
        return Math.sqrt(x*x + y*y);
    }

    static public double getAngle(double x1, double y1, double x2, double y2){
		if ((module(x1, y1) == 0) || (module(x2,y2) == 0)) {
			return 0;
		}

		double a1 = (x1*y2 - y1*x2)/(module(x1,y1) * module(x2,y2));
		double a2 = (x1*x2 + y1*y2)/(module(x1,y1) * module(x2,y2));
		double aa1 = Math.asin(a1);
		double aa2 = Math.acos(a2);
		double a = 0;

		if((a1>=0)&&(a2>=0)){
			a = aa1;
		}
		if((a1>=0)&&(a2<=0)){
			a = /*Math.PI -*/ aa2;
		}
		if((a1<=0)&&(a2<=0)){
			a = 2*Math.PI - aa2;
		}
		if((a1<=0)&&(a2>=0)){
			a = 2*Math.PI - aa2;
		}

		//if (a < 0) {
		 //   a += 2*Math.PI;
		//}
		//Double d = new Double(a);
		//if (d.isNaN()) a = 0;
		return a;
    }

	public Double get() {
		Robot r = getRobot();

		Circle c = new Circle(0, 0, 0);
		double min = 1000000;
		for (WorldObject wo : getWorld().getWorldObjects()) {
			if (wo instanceof Obstacle){
				Obstacle o = (Obstacle) wo;
				double d = Math.hypot(r.getX()-o.getX(), r.getY()-o.getY());
				d -= (r.getR() + o.getR())/2.0;
				if (d < min) {
					min = d;
					c = o;
				}
			}
			if (wo instanceof Boundary){
				Boundary b = (Boundary) wo;
				double d = Math.abs(r.getX()-b.getX());
				d = Math.abs(d - r.getR()/2.0);
				if (d < min){
					min = d;
					c = new Circle(0, 0, 0);
					c.setX(r.getX()-1);
					c.setY(r.getY());
				}
				d = Math.abs(r.getY()-b.getY());
				d = Math.abs(d - r.getR()/2.0);
				if (d < min) {
					min = d;
					c = new Circle(0, 0, 0);
					c.setX(r.getX());
					c.setY(r.getY()-1);
				}
				d = Math.abs(r.getX()-(b.getW()+b.getX()));
				d = Math.abs(d - r.getR()/2.0);
				if (d < min) {
					min = d;
					c = new Circle(0, 0, 0);
					c.setX(r.getX()+1);
					c.setY(r.getY());						
				} 
				d = Math.abs(r.getY()-(b.getH()+b.getY()));
				d = Math.abs(d - r.getR()/2.0);
				if (d < min){
					min = d;
					c = new Circle(0, 0, 0);
					c.setX(r.getX());
					c.setY(r.getY()+1);
				}
			}

		}

		double a = r.getA();

		if (!(c instanceof Obstacle)) {
			//System.out.print("bound");
			double foo = getAngle(c.getX()-r.getX(), c.getY()-r.getY(), Math.cos(a),  Math.sin(a));
			foo = 0;
		}
		
		//if (!(c instanceof Obstacle)){
		//	System.out.print(c.getX()-r.getX());
		//	System.out.print(" ");
		//	System.out.print(c.getY()-r.getY());
		//	System.out.println();
		//}


		//System.out.print(c instanceof Obstacle ? "obst" : "bound");
		//System.out.print(" ");
		//System.out.print(c.getX()-r.getX());
		//System.out.print(" ");
		//System.out.print(c.getY()-r.getY());
		//System.out.print(" ");
		//System.out.print(Math.cos(a));
		//System.out.print(" ");
		//System.out.print(Math.sin(a));
		//System.out.print(" ");
		//System.out.print(c.getX());
		//System.out.print(" ");
		//System.out.print(c.getY());
		//System.out.println();
				
		return getAngle(c.getX()-r.getX(), c.getY()-r.getY(), Math.cos(a),  Math.sin(a));
	}

}
