/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.ais;

import java.util.List;
import java.util.Vector;
import robot.EndCycle;
import robot.drivers.AngleDriver;
import robot.drivers.Driver;
import robot.drivers.MovingDriver;
import robot.monitors.TargetAngleMonitor;
import robot.monitors.TargetDistanceMonitor;
import robot.monitors.Monitor;

/**
 *
 * @author stswoon
 */
public class MyAI extends SimpleAI{
	private TargetDistanceMonitor tm;
	private TargetAngleMonitor am;
	private AngleDriver ad;
	private MovingDriver md;

	public MyAI(List<Monitor> monitors, List<Driver> drivers) {
		super(monitors, drivers);
	}

	public void make() {
		for (Driver d : getDrivers()) {
			if (d instanceof AngleDriver) {
				ad = (AngleDriver) d;
			}
			if (d instanceof MovingDriver) {
				md = (MovingDriver) d;
			}
		}
		for (Monitor m : getMonitors()) {
			if (m instanceof TargetDistanceMonitor){
				tm = (TargetDistanceMonitor) m;
			}
			if (m instanceof TargetAngleMonitor){
				am = (TargetAngleMonitor) m;
			}
		}

		monitors2vector();

		//РґР°Р»РµРµ РєРѕРґ СЂР°Р±РѕС‚С‹ СЂРѕР±РѕС‚Р°
		//!!!РЅРµ РІС‹Р·С‹РІР°С‚СЊ РґСЂР°Р№РІРµСЂР° Р±РѕР»СЊС€Рµ РѕРґРЅРѕРіРѕ СЂР°Р·Р°, РЅРµС‚ РїСЂРѕРІРµСЂРєРё Р±С‹Р»Рѕ Р»Рё СЃРґРµР»Р°РЅРѕ РґРµР№СЃС‚РІРёРµ
		//----------------------

		ad.inc();
		ad.inc();
		ad.inc();
		ad.inc();
		ad.inc();
		ad.inc();
		ad.inc();
		ad.inc();
		ad.inc();
		//md.inc();
	}

	private Vector<Double> monitors2vector(){
		Vector<Double> v = new Vector<Double>();
		for(int i = 0; i < 12; i++){
			v.add(new Double(0));
		}
		double d = tm.get();
		double a = am.get();
		int x = -100;
		int y = -100;

		if ((d >= 0) && (d < 5)){
			x = 0;
			//v.set(0, new Double(1));
		} else if ((d >= 5) && (d < 25)){
			x = 1;
			//v.set(1, new Double(1));
		} else if (d >= 25){
			x = 2;
			//v.set(2, new Double(1));
		}

		if (((a >= 0) && (a < Math.PI/4)) ||
			((a >= 7*Math.PI/4) && (a <= 8*Math.PI/4))){
			y = 0;
			//v.set(3, new Double(1));
		} else if ((a >= Math.PI/4) && (a < 3*Math.PI/4)){
			y = 1;
			//v.set(4, new Double(1));
		} else if ((a >= 3*Math.PI/4) && (a < 5*Math.PI/4)){
			y = 2;
			//v.set(5, new Double(1));
		} else if ((a >= 5*Math.PI/4) && (a < 7*Math.PI/4)){
			y = 3;
			//v.set(6, new Double(1));
		}


		v.set(4*x+y, new Double(1));

		System.out.print(Math.round(a/Math.PI*180*100)/100.0);
		System.out.print(" ");
		//System.out.print(d);
		//System.out.print(" ");
		System.out.println(v.toString());

		return v;
	}

	public void education(EndCycle endCycle) {
		//throw new UnsupportedOperationException("Not supported yet.");
	}


}
