/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.ais;

import robot.monitors.Monitor;
import robot.drivers.Driver;
import java.util.List;

/**
 *
 * @author stswoon
 */
abstract public class SimpleAI implements AI{

	private List<Monitor> monitors = null;
	private List<Driver> drivers = null;

	public SimpleAI(List<Monitor> monitors, List<Driver> drivers) {
		setDrivers(drivers);
		setMonitors(monitors);
	}

	public List<Driver> getDrivers() {
		return drivers;
	}

	public void setDrivers(List<Driver> drivers) {
		this.drivers = drivers;
	}

	public List<Monitor> getMonitors() {
		return monitors;
	}

	public void setMonitors(List<Monitor> monitors) {
		this.monitors = monitors;
	}



}
