/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.monitors;

/**
 *
 * @author stswoon
 */
public interface Monitor {

	Object get();

}
