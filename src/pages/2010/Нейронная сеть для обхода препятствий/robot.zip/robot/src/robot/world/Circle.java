/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.world;

/**
 *
 * @author stswoon
 */
public class Circle {

	private double x = 0;
	private double y = 0;
	private double r = 0;

	public Circle(double x, double y, double r) {
		setR(r);
		setX(x);
		setY(y);
	}


	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}
}
