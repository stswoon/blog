/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.monitors;

import java.util.Vector;
import robot.world.Robot;
import robot.world.World;

/**
 *
 * @author stswoon
 */
public class TargetAreaMonitor extends SimpleMonitor{

	private	TargetDistanceMonitor tm = null;
	private	TargetAngleMonitor am = null;
	private final int n = 12; //количество областей
	
	public TargetAreaMonitor(Robot robot, World world, TargetDistanceMonitor tm, TargetAngleMonitor am) {
		super(robot, world);
		this.am = am;
		this.tm = tm;
	}

	public Vector<Double> get() {
		Vector<Double> v = new Vector<Double>();
		for(int i = 0; i < n; i++){
			v.add(new Double(0));
		}
		double d = tm.get();
		double a = am.get();
		int x = -100;
		int y = -100;

		if ((d >= 0) && (d < 5)){
			x = 0;
			//v.set(0, new Double(1));
		} else if ((d >= 5) && (d < 25)){
			x = 1;
			//v.set(1, new Double(1));
		} else if (d >= 25){
			x = 2;
			//v.set(2, new Double(1));
		}

		if (((a >= 0) && (a < Math.PI/4)) ||
			((a >= 7*Math.PI/4) && (a <= 8*Math.PI/4))){
			y = 0;
			//v.set(3, new Double(1));
		} else if ((a >= Math.PI/4) && (a < 3*Math.PI/4)){
			y = 1;
			//v.set(4, new Double(1));
		} else if ((a >= 3*Math.PI/4) && (a < 5*Math.PI/4)){
			y = 2;
			//v.set(5, new Double(1));
		} else if ((a >= 5*Math.PI/4) && (a < 7*Math.PI/4)){
			y = 3;
			//v.set(6, new Double(1));
		}

		if(x >= 0 && y >=0)	v.set(4*x+y, new Double(1));

		//System.out.print(a);
		//System.out.print(" ");
		//System.out.print(d);
		//System.out.print(" ");
		//System.out.println(v.toString());

		return v;
	}

}
