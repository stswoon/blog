/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.ais;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author stswoon
 */
abstract class SimpleNet implements Net, Serializable{

	private Vector<Vector<Double>> w = new Vector<Vector<Double>>();
	private Vector<Double> input = null;
	private Vector<Double> output = null;
	private double a = 0.1;

	public SimpleNet(int nin, int nout) {
		for(int i = 0; i < nout; ++i){
			Vector<Double> v = new Vector<Double>(nin);
			for(int j = 0; j < nin; ++j){
				double x = Math.random();
				while (x < 0.001) x = Math.random();
				v.add(Math.random());
			}
			w.add(v);
		}

		output = new Vector<Double>();
		for (int i = 0; i < nout; i++) {
			output.add(new Double(0));
		}
	}

	static public double activationFunction(double u){
		double a = Math.exp(u);
		double b = Math.exp(-u);

		Double d = (a-b)/(a+b);
		if (d.isNaN()) {
			System.out.println("NaN в активаторной функции");
		}

		return d;
	}

	public void normalize(){
		double sum = 0;
		for (int i = 0; i < w.size(); i++) {
			Vector<Double> v = w.get(i);
			for (int j = 0; j < v.size(); j++) {
				Double d = v.get(j);
				sum += d*d;
			}

		}
		sum = Math.sqrt(sum);
		for (int i = 0; i < w.size(); i++) {
			Vector<Double> v = w.get(i);
			for (int j = 0; j < v.size(); j++) {
				Double d = v.get(j);
				v.set(j, d/sum);
			}

		}
		
	}

	/**
	 * Увеличение всех весов сети, на величину = модулю
	 * самого отрицательного веса + x,
	 * если он есть.
	 * |min| < x => wij += |min| + x
	 */
	public void decNet(double x){
		double min = w.get(0).get(0);
		for (int i = 0; i < w.size(); i++) {
			Vector<Double> vector = w.get(i);
			for (int j = 0; j < vector.size(); j++) {
				Double d = vector.get(j);
				min = Math.min(min, d);
			}
		}

		if (min > x) return;

		min = Math.abs(min) + x;
		for (int i = 0; i < w.size(); i++) {
			Vector<Double> vector = w.get(i);
			for (int j = 0; j < vector.size(); j++) {
				Double d = vector.get(j);
				d += min;
				vector.set(j, d);
			}
		}
	}

	public void setInput(Vector<Double> input) {
		this.input = input;
	}

	public Vector<Double> getOutput() {
		return output;
	}

	public void calculate(){
		output = new Vector<Double>();
		for (int i = 0; i < w.size(); ++i){
			double u = 0;
			Vector<Double> v = w.get(i);
			for(int j = 0; j < v.size(); ++j){
				u += v.get(j)*input.get(j);
			}
			u = activationFunction(u);
			output.add(u);
		}
	}

	public Integer getWinner(){
		double max = output.get(0);
		int maxi = 0;
		for (int i = 0; i < output.size(); i++) {
			if(output.get(i) > max) {
				max = output.get(i);
				maxi = i;
			}
		}

		if(max < 0.000001) maxi = -1;
		return maxi;
	}

	public Integer getLooser(){
		double min = output.get(0);
		int mini = 0;
		for (int i = 0; i < output.size(); i++) {
			if(output.get(i) < min && output.get(i) > 0.000001) {
				min = output.get(i);
				mini = i;
			}
		}

		if(min < 0.000001) mini = -1;
		return mini;
	}

	public double getAverage(int ii, int jj){
		double avr = 0;
		for(int i = 0; i < w.size(); ++i){
			for (int j = 0; j < w.get(i).size(); ++j){
				if (i != ii && j != jj){
					avr += w.get(i).get(j);
				}
			}
		}
		avr /= (double)(w.size()*w.get(0).size() - 1);

		return avr;
	}

	public void setAlpha(double a) {
		if (a < 0) {
			a = 0;
		}
		if (a > 0.3){
			a = 0.3;
		}
		this.a = a;
	}

	public double getAlpha() {
		return a;
	}

	public String getW2String() {
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < w.size(); ++i){
			for (int j = 0; j < w.get(i).size(); ++j){
				Double x = w.get(i).get(j);
				x *= 1000;
				x = (double) Math.round(x);
				x /= 1000.0;
				sb.append(x.toString() + " ");
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	public Vector<Vector<Double>> getW() {
		return w;
	}

	public Vector<Double> getInput() {
		return input;
	}

	public void save(String s){
		ObjectOutputStream out = null;
		try {
			File f = new File(new File("").getAbsolutePath() + s);
			out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
			out.writeObject(this);
			out.close();
		} catch (IOException ex) {
			Logger.getLogger(SimpleNet.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				out.close();
			} catch (IOException ex) {
				Logger.getLogger(SimpleNet.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

	}

	public void load(String s){
		try {
			File f = new File(s);
			ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(f)));
			SimpleNet net = (SimpleNet) in.readObject();
			this.setAlpha(net.getAlpha());
			this.w = net.getW();
			in.close();
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(SimpleNet.class.getName()).log(Level.SEVERE, null, ex);
		} catch (IOException ex) {
			Logger.getLogger(SimpleNet.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

}
