/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.ais;

import java.util.List;
import java.util.Vector;
import robot.EndCycle;
import robot.drivers.AngleDriver;
import robot.drivers.Driver;
import robot.drivers.MovingDriver;
import robot.monitors.TargetAngleMonitor;
import robot.monitors.ObstacleDistanceMonitor;
import robot.monitors.TargetAreaMonitor;
import robot.monitors.TargetDistanceMonitor;
import robot.monitors.Monitor;
import robot.monitors.ObstacleAreaMonitor;

/**
 *
 * @author stswoon
 */
public class NeuroAI extends SimpleAI{

	private TargetNet targetNet = null;
	private ObstacleNet obstacleNet = null;

	private AngleDriver aD = null;
	private	MovingDriver mD = null;
	private ObstacleDistanceMonitor dM = null;
	private	TargetDistanceMonitor tM = null;
	private	TargetAngleMonitor aM = null;
	private TargetAreaMonitor tarM = null;
	private ObstacleAreaMonitor obstM = null;

	public NeuroAI(List<Monitor> monitors, List<Driver> drivers) {
		super(monitors, drivers);
		init();
	}

	private void init(){
		for (Driver d : getDrivers()) {
			if (d instanceof AngleDriver) {
				aD = (AngleDriver) d;
			}
			if (d instanceof MovingDriver) {
				mD = (MovingDriver) d;
			}
		}
		
		for (Monitor m : getMonitors()) {
		/*
			if (m instanceof TargetMonitor){
				tM = (TargetMonitor) m;
			}
			if (m instanceof ObstacleDistanceMonitor){
				dM = (ObstacleDistanceMonitor) m;
			}
			if (m instanceof TargetAngleMonitor){
				aM = (TargetAngleMonitor) m;
			}
		 */
			if(m instanceof TargetAreaMonitor){
				tarM = (TargetAreaMonitor) m;
			}
			if(m instanceof ObstacleAreaMonitor){
				obstM = (ObstacleAreaMonitor) m;
			}
		}

		targetNet = new TargetNet(12,3);
		obstacleNet = new ObstacleNet();
	}

	private void move(int i) {
		if (i == 0){
			aD.inc();
		} else if (i == 1){
			aD.dec();
		} else if (i == 2){
			mD.inc();
		}		
	}

	public void make() {
		Vector<Double> vTar = tarM.get();
		Vector<Double> vObst = obstM.get();

		targetNet.setInput(vTar);
		targetNet.calculate();
		obstacleNet.setInput(vObst);
		obstacleNet.calculate();

		obstacleNet.saveNoZeroResult();

		int x = targetNet.getWinner();
		int y = obstacleNet.getWinner();

		//move(x);
		
		
		if(x != -1){
			if(y == -1) {
				//move(x);
				move(2);
			} else {
				move(y);
			}
		}
		
	}

	private void eduTarget(boolean right){
		if (right) {
			targetNet.setAlpha(targetNet.getAlpha()-0.01);
		} else {
			targetNet.setAlpha(targetNet.getAlpha()+0.001);
		}

		//boolean happy = (tM.get() < oldDtar);
		//boolean happy = (tm.get() < oldD || am.get() < oldA);
		//boolean happy = (tm.get() < oldD && am.get() < oldA);
		//if (happy) {
		//	oldDtar = tM.get();
		//}
		//targetNet.education(win || happy);

		targetNet.education(right);

		System.out.print("TargetNet ");
		System.out.println(targetNet.getAlpha());
	}

	private void eduObstacle(boolean right){
		if (right) {
			obstacleNet.setAlpha(obstacleNet.getAlpha()-0.01);
		} else {
			obstacleNet.setAlpha(obstacleNet.getAlpha()+0.001);
		}

		//boolean happy = (dM.get() > oldDobst) || win;
		obstacleNet.education(right);
		//if (happy) {
		//	oldDobst = dM.get();
		//}

		System.out.print("ObstacleNet ");
		System.out.println(obstacleNet.getAlpha());
	}

	/*
	public void education(EndCycle endCycle){
		if (endCycle == EndCycle.Win) {
			targetNet.setAlpha(targetNet.getAlpha()-0.01);
		} else {
			targetNet.setAlpha(targetNet.getAlpha()+0.001);
		}

		targetNet.education(endCycle == EndCycle.Win);
	}
	 */
	
	public void education(EndCycle endCycle){
		if (endCycle == EndCycle.TimeLimit) {
			obstacleNet.setAlpha(obstacleNet.getAlpha()-0.01);
		} else if (endCycle == EndCycle.Crash) {
			obstacleNet.setAlpha(obstacleNet.getAlpha()+0.001);
		}

		obstacleNet.education(endCycle != EndCycle.Crash && endCycle != EndCycle.Vibration);

		//System.out.print("ObstacleNet ");
		//System.out.println(obstacleNet.getAlpha());
	}
	 

}