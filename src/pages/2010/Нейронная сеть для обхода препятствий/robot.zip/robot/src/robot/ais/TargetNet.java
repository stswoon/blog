/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.ais;

import java.util.Vector;

/**
 *
 * @author stswoon
 */
public class TargetNet extends SimpleNet{

	public TargetNet(int nin, int nout) {
		super(nin, nout);
	}

	public void education(boolean right){
		Vector<Vector<Double>> w = this.getW();
		Vector<Double> input = this.getInput();
		Vector<Double> output = this.getOutput();
		double a = getAlpha();

		if(!right){
			int x = getWinner();
			if (x >= 0) {
				Double y = null;
				for (int i = 0; i < w.get(x).size(); i++) {
					y = w.get(x).get(i);
					y -= a*input.get(i)*output.get(x);
					w.get(x).set(i, y);
				}
			}
		} else {
			Double x = null;
			for(int i = 0; i < w.size(); ++i){
				for (int j = 0; j < w.get(i).size(); ++j){
					x = w.get(i).get(j);
					x += a*input.get(j)*output.get(i);
					//if (x < 0.001) {
					//	x = 0.001;
					//}
					if (10*getAverage(i, j) < x){
						x /= 3.0;
					}
					w.get(i).set(j, x);
				}
			}
		}
	}

}
