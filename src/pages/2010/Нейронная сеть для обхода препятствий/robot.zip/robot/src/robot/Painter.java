/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot;

import java.awt.BasicStroke;
import java.awt.Color;
import robot.world.World;
import robot.world.Robot;
import robot.world.WorldObject;
import robot.world.Target;
import java.awt.Graphics2D;
import robot.world.Boundary;
import robot.world.Obstacle;

/**
 *
 * @author stswoon
 */
public class Painter {
	
	static public void draw(Robot robot, Graphics2D g2, double k){
		int x = (int) (robot.getX() * k);
		int y = (int) (robot.getY() * k);
		int r = (int) (robot.getR() * k);
		double a = robot.getA();
		g2.setColor(Color.BLACK);
		g2.drawOval(x - r/2, y - r/2, r, r);
		int x1 = (int) (x + r * Math.cos(a));
		int y1 = (int) (y + r * Math.sin(a));
		g2.drawLine(x, y, x1, y1);

		//r += 20;
		r += 20*2;
		a = a * 180 / Math.PI;
		g2.drawArc(x - r/2, y - r/2, r, r, (int)-a, 90);
		g2.drawArc(x - r/2, y - r/2, r, r, (int)-a, -90);
		// очень забавно
		//g2.drawArc(x - r/2, y - r/2, r, r, (int)a, 90);
		//g2.drawArc(x - r/2, y - r/2, r, r, (int)-a, (int)a+90);

	}

	static public void draw(Target target, Graphics2D g2, double k){
		int x = (int) (target.getX() * k);
		int y = (int) (target.getY() * k);
		int r = (int) (target.getR() * k);
		g2.setColor(Color.BLACK);
		g2.fillOval(x - r/2, y - r/2, r, r);
	}

	static public void draw(Obstacle obstacle, Graphics2D g2, double k){
		int x = (int) (obstacle.getX() * k);
		int y = (int) (obstacle.getY() * k);
		int r = (int) (obstacle.getR() * k);
		g2.setColor(Color.BLUE);
		g2.fillOval(x - r/2, y - r/2, r, r);
	}

	static public void draw(Boundary b, Graphics2D g2, double k){
		int x = (int) (b.getX() * k);
		int y = (int) (b.getY() * k);
		int h = (int) (b.getH() * k);
		int w = (int) (b.getW() * k);
		g2.setColor(Color.BLACK);
		g2.setStroke(new BasicStroke(5));
		g2.drawRect(x, y, w, h);
		g2.setStroke(new BasicStroke(1));
	}

	static public void draw(World world, Graphics2D g2, double k){
		g2.clearRect(0, 0, 1000, 1000);
		for (WorldObject wo : world.getWorldObjects()) {
			draw(wo, g2, k);
		}
	}

	private static void draw(WorldObject wo, Graphics2D g2, double k) {
		if (wo instanceof Robot) {
			draw((Robot)wo, g2, k);
		}
		if (wo instanceof Target) {
			draw((Target)wo, g2, k);
		}
		if (wo instanceof Obstacle){
			draw((Obstacle)wo, g2, k);
		}
		if (wo instanceof Boundary){
			draw((Boundary)wo, g2, k);
		}
	}


}



/*
	static public void draw(Robot robot, Graphics2D g2, double k){
		int x = (int) (robot.getX() * k);
		int y = (int) (robot.getY() * k);
		int r = (int) (robot.getR() * k);
		double a = robot.getA();
		g2.setColor(Color.BLACK);
		g2.drawOval(x - r/2, y - r/2, r, r);
		int x1 = (int) (x + r * Math.cos(a));
		int y1 = (int) (y + r * Math.sin(a));
		g2.drawLine(x, y, x1, y1);

		r += 20;
		a = a * 180 / Math.PI;
		g2.drawArc(x - r/2, y - r/2, r, r, (int)-a, 90);
		g2.drawArc(x - r/2, y - r/2, r, r, (int)-a, -90);
		// очень забавно
		//g2.drawArc(x - r/2, y - r/2, r, r, (int)a, 90);
		//g2.drawArc(x - r/2, y - r/2, r, r, (int)-a, (int)a+90);

	}

	static public void draw(Target target, Graphics2D g2, double k){
		int x = (int) (target.getX() * k);
		int y = (int) (target.getY() * k);
		int r = (int) (target.getR() * k);
		g2.setColor(Color.BLACK);
		g2.fillOval(x - r/2, y - r/2, r, r);
	}

	static public void draw(Obstacle obstacle, Graphics2D g2, double k){
		int x = (int) (obstacle.getX() * k);
		int y = (int) (obstacle.getY() * k);
		int r = (int) (obstacle.getR() * k);
		g2.setColor(Color.BLUE);
		g2.fillOval(x - r/2, y - r/2, r, r);
	}

	static public void draw(Boundary b, Graphics2D g2, double k){
		int x = (int) (b.getX() * k);
		int y = (int) (b.getY() * k);
		int h = (int) (b.getH() * k);
		int w = (int) (b.getW() * k);
		g2.setColor(Color.BLACK);
		g2.setStroke(new BasicStroke(5));
		g2.drawRect(x, y, w, h);
		g2.setStroke(new BasicStroke(1));
	}
*/