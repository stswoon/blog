/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.ais;

import java.util.Vector;

/**
 *
 * @author stswoon
 */
public class ObstacleNet extends SimpleNet{

	public ObstacleNet() {
		super(6, 3);
	}

	public ObstacleNet(int nin, int nout) {
		super(nin, nout);
	}

	private ObstacleNet old = null;
	private void initOld(){
		old = new ObstacleNet();
		Vector<Double> v = new Vector<Double>();
		for (int i = 0; i < 6; i++) {
			v.add(new Double(0));
		}
		old.setInput(v);
		old.calculate();	
	}
	public void saveNoZeroResult(){
		if (getWinner() > -1) {
			old = new ObstacleNet();

			Vector<Double> v = new Vector<Double>();
			for (int i = 0; i < this.getInput().size(); i++) {
				v.add(this.getInput().get(i));
			}

			old.setInput(v);
			for (int i = 0; i < this.getW().size(); i++) {
				for (int j = 0; j < this.getW().get(i).size(); j++) {
					Double d = this.getW().get(i).get(j);
					old.getW().get(i).set(j, d);
				}

			}
			old.calculate();
		}
	}

	public void education(boolean right){
		if (old == null) initOld();

		Vector<Vector<Double>> w = this.getW();
		Vector<Double> input = old.getInput();
		Vector<Double> output = old.getOutput();
		double a = getAlpha();

		if(!right){
			int x = getWinner();
			if (x >= 0) {
				Double y = null;
				for (int i = 0; i < w.get(x).size(); i++) {
					y = w.get(x).get(i);
					y -= a*input.get(i)*output.get(x);
					w.get(x).set(i, y);
				}
				decNet(1);
			}
		} else {
			
			Double x = null;
			for(int i = 0; i < w.size(); ++i){
				for (int j = 0; j < w.get(i).size(); ++j){
					x = w.get(i).get(j);
					x += a*input.get(j)*output.get(i);
					//if (x < 0.001) {
					//	x = 0.001;
					//}
					if (10*getAverage(i, j) < x){
						x /= 3.0;
					}
					w.get(i).set(j, x);
				}
			}
			 
		}
	}

}
