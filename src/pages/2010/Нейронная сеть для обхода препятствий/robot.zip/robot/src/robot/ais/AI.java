/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.ais;

import robot.EndCycle;

/**
 *
 * @author stswoon
 */
public interface AI {

	/**
	 * do the work in one cicle
	 */
	void make();

	/**
	 * this func run after every end of cycle,
	 * if there is no anything to learn for this
	 * ai then you should override this func empty.
	 */
	void education(EndCycle endCycle);

}
