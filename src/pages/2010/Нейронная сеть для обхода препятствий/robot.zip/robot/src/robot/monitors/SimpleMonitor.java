/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.monitors;

import robot.world.World;
import robot.world.Robot;

/**
 *
 * @author stswoon
 */
abstract public class SimpleMonitor implements Monitor{

	private Robot robot;
	private World world;

	public SimpleMonitor(Robot robot, World world) {
		this.robot = robot;
		this.world = world;
	}

	public Robot getRobot() {
		return robot;
	}

	public void setRobot(Robot robot) {
		this.robot = robot;
	}

	public World getWorld() {
		return world;
	}

	public void setWorld(World world) {
		this.world = world;
	}


}
