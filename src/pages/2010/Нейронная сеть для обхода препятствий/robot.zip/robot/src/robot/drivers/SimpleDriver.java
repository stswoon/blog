/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.drivers;

import robot.world.Robot;

/**
 *
 * @author stswoon
 */
abstract public class SimpleDriver implements Driver{

	private Robot robot = null;
	private double delta = 0.1; //величина, на которую изменяется значение свойств робота
	
	abstract void inc();

	abstract void dec();

	public SimpleDriver(Robot robot, double delta) {
		setRobot(robot);
		setDelta(delta);
	}

	public Robot getRobot() {
		return robot;
	}

	public void setRobot(Robot robot) {
		this.robot = robot;
	}

	public double getDelta() {
		return delta;
	}

	public void setDelta(double delta) {
		this.delta = delta;
	}


}
