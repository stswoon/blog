/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot;

import robot.world.World;
import robot.world.Robot;
import robot.world.WorldObject;
import robot.world.Target;
import robot.drivers.MovingDriver;
import robot.monitors.Monitor;
import robot.drivers.Driver;
import robot.monitors.TargetDistanceMonitor;
import robot.drivers.AngleDriver;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import robot.ais.NeuroAI;
import robot.monitors.TargetAngleMonitor;
import robot.monitors.ObstacleDistanceMonitor;
import robot.monitors.ObstacleAngleMonitor;
import robot.monitors.ObstacleAreaMonitor;
import robot.monitors.TargetAreaMonitor;
import robot.world.Boundary;
import robot.world.Obstacle;

/**
 *
 * @author stswoon
 */
public class Project {

	private World w = null;
	private int time = 0;
	private int timeLimit = 2000;
	private int generation = 0;
	private int generationsLimit = 300;

	private int koef = 1;
	private boolean draw = false;
	private int sleepTime = 1;
	private int emptyFrameCount = 1;
	private Graphics2D g2 = null;

	private boolean randomPlace = true;
	private boolean withObstacle = true;
	private int obstacleCount = 20;
	private double winDist = 20;
	private int width = 700;
	private int height = 400;
	private int space = 40;
	private int obstacleR = 20;

	private NeuroAI ai = null;

	private List<Double> robotCoord = new ArrayList<Double>();

	public Project(Graphics2D g2) {
		this.g2 = g2;
		clearWorld();
	}

	public void clearWorld(){
		w = new World();
		initTargetAndRobot();
	}

	private void initTargetAndRobot(){
		Robot r = new Robot(0, 0, 10);
		Target t = new Target(0, 0, 10);
		List<WorldObject> wos = new ArrayList<WorldObject>();
		wos.add(t);
		wos.add(r);
		w.setWorldObjects(wos);
		initWorldOnStartPosition();
		initAI();
	}

	private void randomPlace(){
		int x = (int) Math.round(Math.random() * width);
		while (x > (150-space) && x < (150+space)) x = (int) Math.round(Math.random() * width);
		int y = (int) Math.round(Math.random() * height);
		while (y > (150-space) && y < (150+space)) y = (int) Math.round(Math.random() * height);
		w.getFirstTarget().setX(x);
		w.getFirstTarget().setY(y);
		w.getFirstRobot().setX(150);
		w.getFirstRobot().setY(150);
		w.getFirstRobot().setA(Math.PI*2*Math.random());
	}

	private void initObstacles(){
		deleteObstacles();
		Robot r = w.getFirstRobot();
		Target t = w.getFirstTarget();

		int l = space;
		for (int i = 0; i < obstacleCount; i++){
			int x = (int) Math.round(Math.random() * width);
			//while ((x > t.getX()-l && x < t.getX()+l) || (x > r.getX()-l && x < r.getX()+l))
			//	x = (int) Math.round(Math.random() * width);
			int y = (int) Math.round(Math.random() * height);
			while ((x > t.getX()-l && x < t.getX()+l && y > t.getY()-l && y < t.getY()+l) ||
				   (x > r.getX()-l && x < r.getX()+l && y > r.getY()-l && y < r.getY()+l))
				y = (int) Math.round(Math.random() * height);
			w.getWorldObjects().add(new Obstacle(x, y, obstacleR));
		}
		w.getWorldObjects().add(new Boundary(0, 0, width*koef, height*koef));
	}
	
	private void deleteObstacles(){
		Vector<WorldObject> v = new Vector<WorldObject>();
		for (WorldObject wo : w.getWorldObjects()) {
			if ((wo instanceof Target) || (wo instanceof Robot)) {
				v.add(wo);
			}
		}
		w.setWorldObjects(v);
	}

	public void initWorldOnStartPosition(){
		if(randomPlace) {
			randomPlace();
		} else {
			w.getFirstRobot().setX(150);
			w.getFirstRobot().setY(150);
			w.getFirstRobot().setA(0);
			w.getFirstTarget().setX(50);
			w.getFirstTarget().setY(50);
		}
		if (withObstacle) {
			initObstacles();
		} else {
			deleteObstacles();
		}
	}

	private void initAI(){
		Robot r = w.getFirstRobot();
		AngleDriver ad = new AngleDriver(r, 0.03);
		MovingDriver md = new MovingDriver(r, 0.5);
		List<Driver> ds = new ArrayList<Driver>();
		ds.add(md);
		ds.add(ad);
		TargetDistanceMonitor tm = new TargetDistanceMonitor(r, w);
		TargetAngleMonitor am = new TargetAngleMonitor(r, w);
		ObstacleDistanceMonitor dm = new ObstacleDistanceMonitor(r, w);
		ObstacleAngleMonitor obstacleAngleMonitor = new ObstacleAngleMonitor(r, w);
		TargetAreaMonitor areamon = new TargetAreaMonitor(r, w, tm, am);
		ObstacleAreaMonitor obstmon = new ObstacleAreaMonitor(r, w, dm, obstacleAngleMonitor);
		List<Monitor> ms = new ArrayList<Monitor>();
		ms.add(tm);
		ms.add(am);
		ms.add(dm);
		ms.add(obstacleAngleMonitor);
		ms.add(areamon);
		ms.add(obstmon);
		ai = new NeuroAI(ms, ds);
	}

	public boolean isWin(){
		boolean b = (Math.hypot(w.getFirstRobot().getX() - w.getFirstTarget().getX(),
								w.getFirstRobot().getY() - w.getFirstTarget().getY()) < winDist);
		return b;
	}

	public boolean isCrash(){
		Robot r = w.getFirstRobot();
		for (WorldObject wo : w.getWorldObjects()) {
			if (wo instanceof Obstacle){
				Obstacle obst = (Obstacle) wo;
				double x = Math.hypot(r.getX()-obst.getX(), r.getY()-obst.getY());
				if (x < (r.getR()+obst.getR())/2.0) {
					return true;
				}
			}
			if (wo instanceof Boundary){
				Boundary b = (Boundary) wo;
				if ((Math.abs(r.getX()-b.getX()) < r.getR()/2.0) ||
					(Math.abs(r.getY()-b.getY()) < r.getR()/2.0) ||
					(Math.abs(r.getX()-(b.getW()+b.getX())) < r.getR()/2.0) ||
					(Math.abs(r.getY()-(b.getH()+b.getY())) < r.getR()/2.0)){
					return true;
				}
			}
		}
		return false;
	}

	public boolean isVibration(){
		double dist = 0;
		double x1 = robotCoord.get(0);
		double y1 = robotCoord.get(0+1);
		for (int i = 2; i < robotCoord.size(); i += 2) {
			double x2 = robotCoord.get(i);
			double y2 = robotCoord.get(i+1);
			double d = Math.hypot(x2-x1, y2-y1);
			dist += d;
			x1 = x2;
			y1 = y2;
		}

		return dist < 3;
	}
	private void forVibration(){
		double x = w.getFirstRobot().getX();
		double y = w.getFirstRobot().getY();
		robotCoord.add(x);
		robotCoord.add(y);
		if (robotCoord.size() > 50) {
			robotCoord.remove(0);
			robotCoord.remove(0);
		}
	}

	public void draw(){
		if (time % emptyFrameCount == 0){
			Painter.draw(w, g2, koef);
			try {
				Thread.sleep(sleepTime);
			} catch (InterruptedException ex) {
				Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	private void oneStep(){
		if(!isWin() && !isCrash()){
			ai.make();
			forVibration();
			if (draw){
				draw();
			}
		}
	}

	public void cycle(){
		time = 0;
		while (time < timeLimit){
			oneStep();
			time++;
		}

		//if(isVibration()) {
		//	ai.education(EndCycle.Vibration);
		//	System.out.println("vibration");
		//}
	}

	public void makeGenerations(){
		generation = 0;
		while (generation < generationsLimit) {
			initWorldOnStartPosition();
			cycle();


			/*
			if (isWin()) {
				ai.education(EndCycle.Win);
			} else {
				ai.education(EndCycle.TimeLimit);
			}
			 */


			
			if (isWin()) {
				ai.education(EndCycle.Win);
			} else if(isCrash()) {
				ai.education(EndCycle.Crash);
			} else if(isVibration()) {
				ai.education(EndCycle.Vibration);
			} else {
				ai.education(EndCycle.TimeLimit);
			}
			 
			
			generation++;
		}
	}

	public void statistic(int n){
		int k = 0;
		for(int i = 0; i < n; ++i){
			clearWorld();
			makeGenerations();
			cycle();
			if (!isCrash()){
				k++;
			}
			if(isVibration()) {
				System.out.print("vibration");
				cycle();
				if (isVibration()) {
					System.out.print(" checked");
					k--;
				}
				System.out.println();
				//this.setDraw(true);
				//cycle();
				//this.setDraw(false);
			}
			System.out.print(i+1);
			System.out.print("/");
			System.out.print(n);
			System.out.print(" (");
			System.out.print(k/(i+1.0));
			System.out.println(")");
		}
		double foo = k*10000/(n+0.0);
		foo = Math.round(foo);
		foo = foo / 100;
		k = (int) foo;
		System.out.print(k);
		System.out.println("%");
	}

	public double getWinDist() {
		return winDist;
	}
	public void setWinDist(double winDist) {
		this.winDist = winDist;
	}
	public int getSleepTime() {
		return sleepTime;
	}
	public void setSleepTime(int sleepTime) {
		this.sleepTime = sleepTime;
	}
	public int getGenerationsLimit() {
		return generationsLimit;
	}
	public void setGenerationsLimit(int generationsLimit) {
		this.generationsLimit = generationsLimit;
	}
	public boolean isDraw() {
		return draw;
	}
	public void setDraw(boolean draw) {
		this.draw = draw;
	}
	public int getKoef() {
		return koef;
	}
	public void setKoef(int k) {
		this.koef = k;
	}
	public int getTimeLimit() {
		return timeLimit;
	}
	public void setTimeLimit(int timeLimit) {
		this.timeLimit = timeLimit;
	}
	public boolean isRandomPlace() {
		return randomPlace;
	}
	public void setRandomPlace(boolean rand) {
		this.randomPlace = rand;
	}
	public int getEmptyFrameCount() {
		return emptyFrameCount;
	}
	public void setEmptyFrameCount(int emptyFrameCount) {
		this.emptyFrameCount = emptyFrameCount;
	}
	public boolean isWithObstacle() {
		return withObstacle;
	}
	public void setWithObstacle(boolean withObstacle) {
		this.withObstacle = withObstacle;
	}
	public int getObstacleCount() {
		return obstacleCount;
	}
	public void setObstacleCount(int obstacleCount) {
		this.obstacleCount = obstacleCount;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getObstacleR() {
		return obstacleR;
	}
	public void setObstacleR(int obstacleR) {
		this.obstacleR = obstacleR;
	}
	public int getSpace() {
		return space;
	}
	public void setSpace(int space) {
		this.space = space;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public void setG2(Graphics2D g2) {
		this.g2 = g2;
	}

}
