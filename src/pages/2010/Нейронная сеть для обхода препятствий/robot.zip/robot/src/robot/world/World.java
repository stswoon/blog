/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package robot.world;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author stswoon
 */
public class World {

	private List<WorldObject> worldObjects = new ArrayList<WorldObject>();

	public List<WorldObject> getWorldObjects() {
		return worldObjects;
	}

	public void setWorldObjects(List<WorldObject> worldObjects) {
		this.worldObjects = worldObjects;
	}

	public Robot getFirstRobot(){
		for (WorldObject wo : worldObjects) {
			if (wo instanceof Robot){
				return (Robot) wo;
			}
		}
		return null;
	}

	public Target getFirstTarget(){
		for (WorldObject wo : worldObjects) {
			if (wo instanceof Target){
				return (Target) wo;
			}
		}
		return null;
	}

}
